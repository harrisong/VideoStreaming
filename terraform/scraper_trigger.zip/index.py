import json
import boto3
import os
import uuid

ecs = boto3.client('ecs')

def handler(event, context):
    try:
        # Parse the request body
        if 'body' in event:
            body = json.loads(event['body'])
        else:
            body = event
        
        youtube_url = body.get('youtube_url')
        user_id = body.get('user_id', 1)
        
        if not youtube_url:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({'error': 'youtube_url is required'})
            }
        
        # Generate a unique task name
        task_name = f"scraper-{str(uuid.uuid4())[:8]}"
        
        # Override the container command with the actual URL
        task_definition = os.environ['TASK_DEFINITION']
        
        # Run the ECS task
        response = ecs.run_task(
            cluster=os.environ['ECS_CLUSTER_NAME'],
            taskDefinition=task_definition,
            launchType='FARGATE',
            networkConfiguration={
                'awsvpcConfiguration': {
                    'subnets': os.environ['SUBNET_IDS'].split(','),
                    'securityGroups': [os.environ['SECURITY_GROUP']],
                    'assignPublicIp': 'DISABLED'
                }
            },
            overrides={
                'containerOverrides': [
                    {
                        'name': 'scraper',
                        'command': ['youtube_scraper', '--url', youtube_url, '--user-id', str(user_id)]
                    }
                ]
            },
            tags=[
                {
                    'key': 'Name',
                    'value': task_name
                },
                {
                    'key': 'Type',
                    'value': 'OnDemandScraper'
                }
            ]
        )
        
        task_arn = response['tasks'][0]['taskArn']
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'message': 'Scraper task started successfully',
                'task_arn': task_arn,
                'task_name': task_name,
                'youtube_url': youtube_url
            })
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': str(e)})
        }
